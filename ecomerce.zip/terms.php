   <!--Modal Log-out --> 

            <div class="modal fade" id="logout" tabindex="-1">
            <div class="modal-dialog">
              <div class="modal-content">
                <div class="modal-header">
                </div>
                <div class="modal-body">

 <h1>You can create you own terms and condition</h1>

</div>
 
</div>
</div>    
</div>  
                                      
          <!--Logout end -->  